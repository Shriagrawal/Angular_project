export class Language{
    language : string
    photo : string
    id : number
    constructor(lang:string,img:string,idno:number){
        this.language = lang
        this.photo = img
        this.id = idno
    }

}