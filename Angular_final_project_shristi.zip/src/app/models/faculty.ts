export class Faculty{

    id : number
    FacId : number


    constructor(idno : number,facid : number){
       this.id = idno
       this.FacId = facid
    }

}