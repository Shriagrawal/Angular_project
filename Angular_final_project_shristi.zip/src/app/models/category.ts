export class Category{

    id : string
    catDescription : string

    constructor(idno : string,catdescription : string){
       
       this.id = idno 
       this.catDescription = catdescription
    }

}