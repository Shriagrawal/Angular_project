export class Tests{
    course : string
    constructor(topic : string){
        this.course = topic
    }
}