export class Trainee{
    id : number
    userId : number
    constructor(idno : number,userid : number){
       this.id = idno
       this.userId = userid
    }

}