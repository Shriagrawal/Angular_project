export class Address{
    noService : number 
    houseNo : number
    constructor(noservice : number,houseno : number){
       this.noService = noservice
       this.houseNo = houseno
    }

}