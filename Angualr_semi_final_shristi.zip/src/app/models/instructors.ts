export class InstructorName{
    profName : string
    constructor(teacher : string){
        this.profName = teacher
    }
}