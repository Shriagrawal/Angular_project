import { Directive, EventEmitter } from '@angular/core';

@Directive({
  selector: '[appAddToDashboard]'
})
export class AddToDashboardDirective {

  constructor() { }   
}
