import { AddToDashboardDirective } from './add-to-dashboard.directive';

describe('AddToDashboardDirective', () => {
  it('should create an instance', () => {
    const directive = new AddToDashboardDirective();
    expect(directive).toBeTruthy();
  });
});
